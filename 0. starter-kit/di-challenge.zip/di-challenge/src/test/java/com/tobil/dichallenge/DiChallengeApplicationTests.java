package com.tobil.dichallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
