package com.tobil.dichallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiChallengeApplication.class, args);
	}

}
